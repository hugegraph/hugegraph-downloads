#!/bin/bash

echo "Start deploy..."
echo "Finish deploy."
