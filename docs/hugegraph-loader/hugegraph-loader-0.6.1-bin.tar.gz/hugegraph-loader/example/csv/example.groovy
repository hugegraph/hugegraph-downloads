inputfiledir = "example/csv/"
personInput = File.csv(inputfiledir + "vertex_person.csv")
softwareInput = File.csv(inputfiledir + "vertex_software.csv")
knowsInput = File.csv(inputfiledir + "edge_knows.csv")
createdInput = File.csv(inputfiledir + "edge_created.csv")

//Specifies what data source to load using which mapper (as defined inline)

load(personInput).asVertices {
    label "person"
    keys "name"
    enableLabelIndex false
}

load(softwareInput).asVertices {
    label "software"
    keys "name"
}

load(knowsInput).asEdges {
    label "knows"
    outV {
        label "person"
        keys "aname"
    }
    inV {
        label "person"
        keys "bname"
    }
}

load(createdInput).asEdges {
    label "created"
    outV {
        label "person"
        keys "aname"
    }
    inV {
        label "software"
        keys "bname"
    }
    enableLabelIndex false
}
