inputfiledir = "example/json/"
personInput = File.json(inputfiledir + "vertex_person.json")
softwareInput = File.json(inputfiledir + "vertex_software.json")
knowsInput = File.json(inputfiledir + "edge_knows.json")
createdInput = File.json(inputfiledir + "edge_created.json")

//Specifies what data source to load using which mapper (as defined inline)

load(personInput).asVertices {
    label "person"
    mapping "name", "id"
    enableLabelIndex false
}

load(softwareInput).asVertices {
    label "software"
    mapping "name", "id"
}

load(knowsInput).asEdges {
    label "knows"
    outV {
        label "person"
        mapping "aname", "id"
    }
    inV {
        label "person"
        mapping "bname", "id"
    }
}

load(createdInput).asEdges {
    label "created"
    outV {
        label "person"
        mapping "aname","id"
    }
    inV {
        label "software"
        mapping "bname", "id"
    }
    enableLabelIndex false
}
