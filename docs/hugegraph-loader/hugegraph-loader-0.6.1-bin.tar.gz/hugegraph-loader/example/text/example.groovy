inputfiledir = "example/text/"
personInput = File.text(inputfiledir + "vertex_person.text").delimiter('|')
softwareInput = File.text(inputfiledir + "vertex_software.text").delimiter('|')
knowsInput = File.text(inputfiledir + "edge_knows.text").delimiter('|')
createdInput = File.text(inputfiledir + "edge_created.text").delimiter('|')

//Specifies what data source to load using which mapper (as defined inline)

load(personInput).asVertices {
    label "person"
    keys "name"
    enableLabelIndex false
}

load(softwareInput).asVertices {
    label "software"
    keys "name"
}

load(knowsInput).asEdges {
    label "knows"
    outV {
        label "person"
        keys "aname"
    }
    inV {
        label "person"
        keys "bname"
    }
}

load(createdInput).asEdges {
    label "created"
    outV {
        label "person"
        keys "aname"
    }
    inV {
        label "software"
        keys "bname"
    }
    enableLabelIndex false
}
