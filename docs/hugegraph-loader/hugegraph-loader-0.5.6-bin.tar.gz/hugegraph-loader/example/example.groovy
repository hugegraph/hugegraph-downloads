/*
 * Copyright 2017 HugeGraph Authors
 *
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with this
 * work for additional information regarding copyright ownership. The ASF
 * licenses this file to You under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

inputfiledir = "example/"
personInput = File.text(inputfiledir + "personVertex.csv").delimiter('|')
softwareInput = File.text(inputfiledir + "softwareVertex.csv").delimiter('|')
knowsInput = File.text(inputfiledir + "knowsEdge.csv").delimiter('|')
createdInput = File.text(inputfiledir + "createdEdge.csv").delimiter('|')

//Specifies what data source to load using which mapper (as defined inline)

load(personInput).asVertices {
    label "person"
    keys "name"
    enableLabelIndex false
}

load(softwareInput).asVertices {
    label "software"
    keys "name"
}

load(knowsInput).asEdges {
    label "knows"
    outV {
        label "person"
        keys "aname"
    }
    inV {
        label "person"
        keys "bname"
    }
}

load(createdInput).asEdges {
    label "created"
    outV {
        label "person"
        keys "aname"
    }
    inV {
        label "software"
        keys "bname"
    }
    enableLabelIndex false
}
