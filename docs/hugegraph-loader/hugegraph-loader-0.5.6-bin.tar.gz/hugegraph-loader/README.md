# HugeLoader

HugeLoader is a command line utility for loading small to medium size graph datasets 
into the HugeGraph database from various input sources.

## Usage

HugeLoader is invoked on the command line with variable number of configuration option-value pairs.


```text
Usage: bin/hugeloader [[-option value]...]
            (to load data into a graph according to the mapping)
       bin/hugeloader -help
            (to show this output and all available configuration options)
Example: bin/hugeloader -g hugegraph -f example/example.groovy
Example: bin/hugeloader -g hugegraph1 -f example/example_customize.groovy -idStrategy customize_string
Example: bin/hugeloader -g hugegraph1 -f example/example_customize.groovy -idStrategy customize_number
```

Options include:

Required(Y/N) | Option | Default | Description
 --- | --- | --- | --- | ---
Y | -f | NONE | The path of mapping script file to load.
Y | -g | NONE | The namespace of the graph to load into.
N | -h | localhost | The HugeServer to connect.
N | -p | 8080 | The port of HugeServer.
N | -createSchema | true | Configures the data loader to create the schema.
N | -dryrun | false | If dryrun is true, will not execute the loading process.
N | -schemaOutputFile | schema.groovy | The output filename of schema.
N | -numThreads | availableProcessors() * 2 - 1| Number of threads to use
N | -batchSize | 500 | The number of lines in each submit.
N | -numFutures | 100 | Number of Java driver futures in flight.
N | -terminateTimeout | 10 | Setting the timeout of awaitTermination in seconds.
N | -maxParseErrors | 1 | Maximum number of rows that do not parse to allow before exiting.
N | -maxInsertErrors | BATCH_SIZE | Maximum number of rows that do not insert to allow before exiting.
N | -timeout | 100 | Setting the max timeout of loading data.
N | -retryTimes | 10 | Setting the max retry times when loading timeout.
N | -retryIntervalTime | 10 | Setting the interval time before retrying.
N | -loadNew         | flase | Check the vertices exist or not while inserting edges.
N | -idStrategy      | primary_key | The Strategy to generate id, can be set to customize_string/customize_number/primary_key.
N | -invalidKeyRegex | null | Filter out key matched the regex, and filter out null or '' keys by default. 
 
## Custom Loading Scripts

A custom loading script defines two things: *data inputs* and *data mappings*. 

### Data Input

A data input defines where the data is coming from and how to read/parse the data.  
All input data is normalized into a *document structured* representation, i.e. a nested maps data structure with `String` keys.

HugeGraph supports the following file based data inputs ,all of which are accessed via `File`:  

* CSV: `input = File.csv(filename)`
* JSON: `input = File.json(filename)`
* Delimited Text: `input = File.text(filename).delimiter("::").header('userid', 'gender', 'age', 'zip')`

### Data Mapping
A data mapping defines how the (document structured) input records for a particular data input are mapped into the graph.
First, you have to decide: Does the data input contain vertex or edge records?
If the data input defines vertex records, the data mapping is defined via
```groovy
load(source1).asVertices(vertexMapper)
```
and if you are loading edge data use
```groovy
load(source1).asEdges(edgeMapper)
```

`vertexMapper` and `edgeMapper` define the actual mapping and trace the input record documents by mapping their fields
 onto graph elements. Let's take a look at the example to explain how such a mapping is defined.
 
 ### Example
 In this example, we want to create a graph use the sample data  of author & book.
 
 The `author.json` look like this:  
 
 ```json
 {"name": "Julia Child","gender":"F"}
 {"name": "Simone Beck","gender":"F"}
 {"name": "Louisette Bertholie","gender":"F"}
 {"name": "Patricia Simon","gender":"F"}
 {"name": "Alice Waters","gender":"F"}
 {"name": "Patricia Curtan","gender":"F"}
 {"name": "Kelsie Kerr","gender":"F"}
 {"name": "Fritz Streiff","gender":"F"}
 {"name": "Emeril Lagasse","gender":"F"}
 {"name": "James Beard","gender":"F"}
 ```
 
 The `book.json` look like this:  
 ```json
 {"name":"The Art of French Cooking, Vol. 1","year":1961,"ISBN":"none"}
 {"name":"Simca's Cuisine: 100 Classic French Recipes for Every Occasion","year":1972,"ISBN":"0-394-40152-2"}
 {"name":"The French Chef Cookbook","year":1968,"ISBN":"0-394-40135-2"}
 {"name":"The Art of Simple Food: Notes, Lessons, and Recipes from a Delicious Revolution","year":2007,"ISBN":"0-307-33679-4"}
 ```
 
 The `authorBook.json` look like this:  
 
 ```json
 {"bname":"The Art of French Cooking, Vol. 1","aname":"Julia Child","test":"test","sex":"F"}
 {"bname":"The Art of French Cooking, Vol. 1","aname":"Simone Beck","test":"test","sex":"F"}
 {"bname":"The Art of French Cooking, Vol. 1","aname":"Louisette Bertholie","test":"test","sex":"F"}
 {"bname":"Simca's Cuisine: 100 Classic French Recipes for Every Occasion","aname":"Simone Beck","test":"test","sex":"F"}
 {"bname":"Simca's Cuisine: 100 Classic French Recipes for Every Occasion","aname":"Patricia Simon","test":"test","sex":"F"}
 {"bname":"The French Chef Cookbook","aname":"Julia Child","test":"test","sex":"F"}
 {"bname":"The Art of Simple Food: Notes, Lessons, and Recipes from a Delicious Revolution","aname":"Alice Waters","test":"test","sex":"F"}
 {"bname":"The Art of Simple Food: Notes, Lessons, and Recipes from a Delicious Revolution","aname":"Patricia Curtan","test":"test","sex":"F"}
 {"bname":"The Art of Simple Food: Notes, Lessons, and Recipes from a Delicious Revolution","aname":"Kelsie Kerr","test":"test","sex":"F"}
 {"bname":"The Art of Simple Food: Notes, Lessons, and Recipes from a Delicious Revolution","aname":"Fritz Streiff","test":"test","sex":"F"}
 ```
 
Hence, we write the following loading script.
```groovy
// DATA INPUT
if (inputpath == '') {
    inputfileV = new java.io.File('.').getCanonicalPath() + '/data/vertices/'
    inputfileE = new java.io.File('.').getCanonicalPath() + '/data/edges/'
}
else {
    inputfileV = inputpath + '/vertices/'
    inputfileE = inputpath + '/edges/'
}

authorInput = File.json(inputfileV + 'author.json')
bookInput = File.json(inputfileV + 'book.json')
authorBookInput = File.json(inputfileE + 'authorBook.json')

//Specifies what data source to load using which mapper (as defined inline)
load(authorInput).asVertices {
    label "author"
    keys "name","gender"
    mapping "gender","sex"
    enableLabelIndex false
}

load(bookInput).asVertices {
    label "book"
    keys "name"
    ignore "ISBN"
}

load(authorBookInput).asEdges {
    label "authored"
    outV {
        label "author"
        keys "aname","sex"
    }
    inV {
        label "book"
        keys "bname"
    }
    enableLabelIndex false
}
```

> When you use 'customize_string' or 'customize_number' idStrategy, do not config 'keys', 
but should has a header named 'id' in the inputFile.
