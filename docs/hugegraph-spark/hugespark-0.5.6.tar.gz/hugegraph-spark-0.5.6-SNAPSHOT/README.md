# Overview
This repository contains a tools which is named `HugeGraph-Spark` for connecting HugeGraph and Spark GraphX. 
HugeGraph-Spark can automatically load the data storage in HugeGraph into HDFS, and transform the 
HugeGraph's graph object to SparkGraphX's graph object. After that, user can do scalable graph analytics 
with Apache Spark GraphX.

# Preparation
Download [spark-2.1.1](http://spark.apache.org), unzip it, then delete out-of-date jars using the following command.

```
rm -rf  jars/guava-14.0.1.jar
rm -rf  jars/jackson-module-scala_2.11-2.6.5.jar
rm -rf  jars/jackson-annotations-2.6.5.jar
rm -rf  jars/jackson-module-paranamer-2.6.5.jar
rm -rf  jars/jackson-databind-2.6.5.jar
rm -rf  jars/jackson-core-2.6.5.jar
```

# Building

Hugegraph-Spark is written in Scala and built using [Apache Maven](http://maven.apache.org/).
The code has been tested on Mac OS X and Linux. To build the code:

```
mvn clean package -DskipTests
```

> Hugegraph-Spark depends on hugegraph-dist, hugegraph-client and spark-2.1.1, so make sure your maven repository has 
the relevant projects.

After successful compilation, The file `target/hugegraph-spark-0.1.0-SNAPSHOT-bin.tar.gz` is generated.
Unzip it and copy jars to ${SPARK_HOME}/jars

```
if [ -d temp ]; then
  rm -rf temp
fi
mkdir temp 
cp target/hugegraph-spark-0.1.0-SNAPSHOT-bin.tar.gz temp
cd temp
tar -xzf hugegraph-spark-0.1.0-SNAPSHOT-bin.tar.gz
cp hugegraph-spark-0.1.0-SNAPSHOT/libs/* ${SPARK_HOME}/jars
```

## Configuration
Parameters can be set either in `spark-default.properties` or command line. 

`` spark-shell --conf spark.hugegraph.snapshot.dir=/tmp/hugesnapshot2``

<table class="table">
<tr><th>Property Name</th><th>Default</th><th>Meaning</th></tr>
<tr>
  <td><code>spark.hugegraph.snapshot.dir</code></td>
  <td><code>/tmp/hugesnapshot</code></td>
  <td>
    The localtion the hugegraph rdd will be persisted when load from backend first time.
  </td>
</tr>
<tr>
  <td><code>spark.hugegraph.conf.url</code></td>
  <td></td>
  <td>
  The url where to get hugegraph conf. (e.g. http://localhost:8080/graphs/hugegraph/conf?token=xxx)
  </td>
</tr>
<tr>
  <td><code>spark.hugegraph.split.size</code></td>
  <td><code>67108864</code></td>
  <td>
  The split size when access vertices and edges from backend. Default: 64M
  </td>
</tr>
<tr>
  <td colspan="3"><code>HugeGraph Bulk Load Configuration</code></td>
</tr>
<tr>
  <td><code>spark.hugegraph.bulkload.database.url</code></td>
  <td><code>http://localhost:8080</code></td>
  <td>
  The hugegraph url when bulkload from hadoop file.
  </td>
</tr>
<tr>
  <td><code>spark.hugegraph.bulkload.database.name</code></td>
  <td><code>hugegraph</code></td>
  <td>
  The hugegraph name when bulkload from hadoop file.
  </td>
</tr>
<tr>
  <td><code>spark.hugegraph.bulkload.vertex.batch.size</code></td>
  <td><code>500</code></td>
  <td>
  Batch size when bulkload vertices to hugegraph.
  </td>
</tr>
<tr>
  <td><code>spark.hugegraph.bulkload.edge.batch.size</code></td>
  <td><code>500</code></td>
  <td>
  batch size when bulkload edges to hugegraph.
  </td>
</tr>
<tr>
  <td><code>spark.hugegraph.bulkload.retry.times</code></td>
  <td><code>10</code></td>
  <td>
  The times to retry when bulk load to hugegraph.
  Only retry when ClientException occurred. Once retried ${retryTimes} times, an Runtime exception will be thrown.
  </td>
</tr>
<tr>
  <td><code>spark.hugegraph.bulkload.retry.sleep.time.ms</code></td>
  <td><code>500</code></td>
  <td>
  The sleep time when exception occurred before next retry when bulk load to hugegraph. 
  </td>
</tr>
</table>

# Internal

## Start

The easiest way to start HugeGraph-Spark is through the Scala shell:

``` 
    ./bin/spark-shell 
```

Import relevant package.

```
  import com.baidu.hugegraph.spark._
```

Initialize graph object.

There are two ways to create a snapshot, Read from hadoop if snapshot already exists. "test" is snapshot name.

```
    val graph = sc.hugeGraph("test")
```
or load data from HugeGraph backend storage by url parameter.

```
  val graph = sc.hugeGraph("test", "http://127.0.0.1:8080/graphs/hugegraph/conf?token=xxxx")
```

## Snapshot 
When initialize with `val graph = sc.hugeGraph("test")` ,it will check whether the directory ${spark.hugegraph.snapshot
.dir}/${graphName} exists. 
If the directory does not exists, then it will load data from backend, else it will read snapshot from hadoop.

* Snapshot from backend

1. Get HugeGraph's vertex splits.

> This method will work only when the backend storage of HugeGraph is setting to Cassandra.

```
graph.graphTransaction()
       .metadata(
         HugeType.VERTEX,"splits",
         new java.lang.Long(hugeSparkConf.hugeGraphSplitSize))
       .asInstanceOf[java.util.List[Split]]
```

2. Get partitions according splits and number of spark executor-cores, trying to divide splits evenly among partitions.
3. Generate HugeGraphVertexRDD by (partitions) and Configuration
4. In each Partition, it read vertex from backend using splits allocated to this partition.


* Read from Hadoop

1. Get the vertex splits size from meta file in directory ${spark.hugegraph.snapshot.dir}/${graphName}/ .
2. Get the partitions according splits.
3. Generate HugeGraphVertexRDD using partitions and Configuration
4. In each Partition, it read vertex num from meta file , then read object from vertex file.
   Assign vertexID with partitionID << 32 + sequence number in every partition.

## Regenerate Id for compatibility with SparkGraphX

As the HugeGraph's VertexId or EdgeId is Object type, it maybe Long or String, 
but the SparkGraphX's Id only support Long. 
it is necessary to regenerate a new Long type Id for compatibility with SparkGraphX. 
HugeGraph-Spark generate new vertexID with partitionID << 32 + sequence number in every partition.

## HugeSparkVertex and HugeSparkEdge

The HugeGraphVertexRDD returns ``Iterator[(String,HugeSparkVertex)]``, The code structure is as follows:

```
class HugeSparkVertex (
      var vertexId: VertexId, //Generated id
      var vertexIdString: String, // HugeGraph vertexId
      var label: String,
      var properties: java.util.Map[String, Object])
  extends Serializable
```

The HugeGraphEdgeRDD returns ``Iterator[HugeSparkEdge] ``, The code structure is as follows:
```
class HugeSparkEdge (var fromVertex: VertexId,
                     var toVertex: VertexId,
                     var fromVertexString: String, //source id read from backend
                     var toVertexString: String, //dest id read from backend
                     var label: String,
                     var properties: java.util.Map[String, Object])
  extends Serializable
```
> By default, the values of fromVertex and toVertex are Long.MinValue.

The core of SparkGraph generation is to generate fromVertex and toVertex.

1. Generate fromVertex. Use fromVertexString as key to generator a new rdd, then join the rdd with hugeVertexRDD.
2. Generate toVertex. Use toVertexString as key to generator a new rdd, then join the rdd with hugeVertexRDD. 
3. Generate GraphX format edgeRDD, using Edge(e.fromVertex,e.toVertex,e).

```
val edgeRDD = hugeEdgeRDD
      .map(e =>(e.fromVertexString,e))
      .leftOuterJoin(hugeVertexRDD,sc.defaultParallelism)
      .map(element => { //join with vertex
          val fromVertexEdge = element._2._1
          val vertex = element._2._2
          if(vertex.isDefined){
            fromVertexEdge.fromVertex = vertex.get.vertexId
          }
          fromVertexEdge
          })
      .map( e =>(e.toVertexString,e))
      .leftOuterJoin(hugeVertexRDD,sc.defaultParallelism)
      .map(element => { //join with vertex
          val toVertexEdge = element._2._1
          val vertex = element._2._2
          if(vertex.isDefined){
            toVertexEdge.toVertex = vertex.get.vertexId
          }
          toVertexEdge
       })
      .map(e => Edge(e.fromVertex,e.toVertex,e))
```

Restrictions: 
> * The number of elements in one partition must be less than 4 billions(1<<32).
> * The number of partitions must be less than 2 billions (1<< 31).

# Example

## Analysis and Query

* Get the number of vertices.

```
   graph.vertices.count()
```

* Get the number of edges.

```
   graph.edges.count()
```

* Get the top 100 outDegrees
```
 
   val top100 = graph.outDegrees.top(100)
   val top100HugeGraphID = sc.makeRDD(top100).join(graph.vertices).collect
   //
   top100HugeGraphID.map(e=> (e._2._2.vertexIdString,e._2._1)).foreach(println)
```

* Get PageRank

The result of PageRank is also a graph. It has `` vertices `` and ``edges``
 ```
  val ranks = graph.pageRank(0.0001)
```

* Take the rank value top 100 vertices. 

```
  val top100 = ranks.vertices.top(100)  
```

## saveGraph & loadGraph

There are three overloaded saveAsObjectFile methods.

```
saveAsObjectFile[T](path: String)

saveAsObjectFile[T](path: String, overwrite: Boolean )

saveAsObjectFile[T](path: Path, overwrite: Boolean )
```

The first method takes a path parameter, it will save the contents of graph to path. 
If the path does not exist, it will be created. It the path already exists, an error will be thrown.

The second method take a overwrite parameter, it let the user to determine whether delete the 
contents in path if it exists.

For example:
```
val graph = sc.hugeGraph("test")
graph.saveAsObjectFile("/tmp/huge/test002")
```

The following code will throw an exception.
```
graph.saveAsObjectFile("/tmp/huge/test002",false)
```

force save the graph, `` true `` means to overwrite if the path exists.
```
graph.saveAsObjectFile("/tmp/huge/test002",true)
```

There are two overloaded loadGraphFromObjectFile methods.

```
loadGraphFromObjectFile[VD: ClassTag, ED: ClassTag](path: String) 
loadGraphFromObjectFile[VD: ClassTag, ED: ClassTag](path: Path) 
```

For example:
```
val graph2 = sc.loadGraphFromObjectFile[HugeSparkVertex,HugeSparkEdge]("/tmp/huge/test002")
```

Check the new graph has the save contents.

```
graph2.vertices.count
```

Compute the graph's PageRank

```
val rank1 = graph.pageRank(0.0001)

rank1.saveAsObjectFile("/tmp/huge/rank",true)
val rank2 = sc.loadGraphFromObjectFile[Double,Double]("/tmp/huge/rank")
```

Check the contents

```
rank1.vertices.top(10)
rank2.vertices.top(10)
```

# Bulk Load
When bulk load content from hadoop file to hugegraph. Set the following parameter in file spark-default in advance.

```
spark.hugegraph.bulkload.database.url http://hugegraph-server-name:hugegraph-server-port
spark.hugegraph.bulkload.database.name hugegraph3
```

Import relevant package.

```
  import com.baidu.hugegraph.spark._
  import com.baidu.hugegraph.spark.bulkload._
```

The example of bulk load vertex

```
 val vertexSaveNum = sc.bulkloadTextHugeGraphVertices("/usr/local/spark/bulkload/vertex",classOf[TextVertexParser])
```

The exmpale of bulk load edge

```
 val edgeSaveNum = sc.bulkloadTextHugeGraphEdges("/usr/local/spark/bulkload/edge",classOf[TextEdgeParser])
```

When bulk load vertex, user must implements TextVertexParser to parse a line into a Vertex object.

TextVertexParser has two method, the first method is `setConfigure`, after call this method, the fields of this class 
must be set properly.

The second method is `getVertex`, it parse a line to a vertex object.

This class can be set in the package when you submit the procedure using spark-submit, 
or you can define it in spark-shell interactive command console.

For example:
```
public class TextVertexParser extends VertexParser {
    public TextVertexParser(){

    }
    public void setConfigure(Configuration conf) {
        keys = new HashSet<String>();
        keys.add("id");
        labelName="person";
        propertyKeys = new ArrayList<String>();
        String propertyKeysStr = "id,screenName,tags,avatar,followersCount,friendsCount,lang,lastSeen,tweetId";
        for(String s : propertyKeysStr.split(",")){
            propertyKeys.add(s);
        }
    }
    public Vertex getVertex(String text) {
        if(text == null || "".equals(text.trim())){
            return null;
        }
        Vertex vertex = new Vertex(this.labelName);
        String[] array = text.split(",");
        for(int i = 0; i < array.length && i < propertyKeys   .size(); i++) {
            vertex.property(propertyKeys.get(i), array[i]);
        }
        return vertex;
    }
}
```

When bulk load edge, user must implements `TextEdgeParser` to parse a line into a edge object.

`TextEdgeParser` has two method, the first method is `setConfigure`, after call this method, the fields of this class
 must be set properly.
 
The second method is `getEdge`, it parse a line to a vertex object.

Like vertex, it's class can be set in the package when you submit the procedure using spark-submit, 
or you can define it in spark-shell interactive command console.

For example:
```
public class TextEdgeParser extends EdgeParser {
    public void setConfigure(Configuration conf) {
        this.edgeLabel = "relation";
        this.frequency = Frequency.SINGLE;
        this.link = new EdgeLink("person","person");
        this.sortKeysSet = new HashSet<String>();
        this.propertiesSet = new HashSet<String>();
    }
    public Edge getEdge(String text) {
        if(text == null || "".equals(text)){
            return null;
        }
        String[] array = text.split(",");
        if(array.length != 2) {
            return null;
        }
        Edge edge = new Edge(this.edgeLabel);
        Map sourceKeys = new HashMap();
        sourceKeys.put("aid",array[0]);
        Map targetKeys = new HashMap();
        targetKeys.put("bid",array[1]);
        edge.source(generateVertex(link.source(), sourceKeys));
        edge.target(generateVertex(link.target(), targetKeys));
        return edge;
    }
    private Vertex generateVertex(String label, Map<String, Object> keys) {
        Vertex vertex = new Vertex(label);
        vertex.id(generateVertexId(label, keys));
        return vertex;
    }
    private String generateVertexId(String label, Map<String, Object> keys) {
        StringBuilder vertexId = new StringBuilder();
        StringBuilder vertexKeysId = new StringBuilder();
        TreeSet<String> orderKeys = new TreeSet<String>(keys.keySet());
        for (String key : orderKeys) {
            vertexKeysId.append(keys.get(key) + "\003");
        }
        vertexId.append(label).append("\002").append(vertexKeysId)
                .deleteCharAt(vertexId.length() - 1);
        return vertexId.toString();
    }
}
```
